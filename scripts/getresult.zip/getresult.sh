#!/bin/sh


curl -X POST "https://a1a-52048-dev-ais-shr1-eus2-1.openai.azure.com/openai/v1/chat/completions" \
-H "Content-Type: application/json" \
-H "Authorization: Bearer EkcbgTCNG9LNU8R6tfSVszuFQzNsijvunOpXRkxua81r177uGE7NJQQJ99BKACHYHv6XJ3w3AAAAACOGdNdE" \
-d '{
    "messages" : [
        {
                "role": "user",
                "content": "I am going to Paris, what should I see?"
        },
        {
                "role": "assistant",
                "content": "Paris, the capital of France, is known for its stunning architecture, art museums, historical landmarks, and romantic atmosphere. Here are some of the top attractions to see in Paris:\n\n1. The Eiffel Tower: The iconic Eiffel Tower is one of the most recognizable landmarks in the world and offers breathtaking views of the city.\n2. The Louvre Museum: The Louvre is one of the worlds largest and most famous museums, housing an impressive collection of art and artifacts, including the Mona Lisa.\n3. Notre-Dame Cathedral: This beautiful cathedral is one of the most famous landmarks in Paris and is known for its Gothic architecture and stunning stained glass windows.\n\nThese are just a few of the many attractions that Paris has to offer. With so much to see and do, its no wonder that Paris is one of the most popular tourist destinations in the world."
        },
        {
                "role": "user",
                "content": "What is so great about #1?"
        }
],
     "max_tokens" : 2048,
     "temperature" : 0.8,
     "top_p" : 0.1,
     "presence_penalty" : 0,
    "model": "Kimi-K2.5"
}'

